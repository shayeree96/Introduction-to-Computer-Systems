/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_492()
{
    return 3284633928U;
}

unsigned addval_128(unsigned x)
{
    return x + 2425378952U;
}

unsigned addval_406(unsigned x)
{
    return x + 3281031256U;
}

void setval_433(unsigned *p)
{
    *p = 3267856712U;
}

unsigned addval_245(unsigned x)
{
    return x + 3281015021U;
}

unsigned getval_273()
{
    return 2455277821U;
}

unsigned getval_111()
{
    return 2462550344U;
}

void setval_301(unsigned *p)
{
    *p = 3347662958U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_416()
{
    return 3221799369U;
}

unsigned getval_179()
{
    return 3380926091U;
}

unsigned getval_153()
{
    return 3674786441U;
}

unsigned addval_162(unsigned x)
{
    return x + 3380920713U;
}

unsigned addval_386(unsigned x)
{
    return x + 3224945065U;
}

void setval_467(unsigned *p)
{
    *p = 3252717896U;
}

void setval_483(unsigned *p)
{
    *p = 3229931137U;
}

void setval_341(unsigned *p)
{
    *p = 3683964553U;
}

unsigned getval_113()
{
    return 3372272265U;
}

void setval_494(unsigned *p)
{
    *p = 3232025225U;
}

unsigned getval_152()
{
    return 3286273352U;
}

void setval_103(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_300(unsigned x)
{
    return x + 3286272456U;
}

void setval_424(unsigned *p)
{
    *p = 2425536905U;
}

void setval_391(unsigned *p)
{
    *p = 3526940297U;
}

unsigned getval_317()
{
    return 3532969609U;
}

void setval_242(unsigned *p)
{
    *p = 3264272009U;
}

unsigned addval_419(unsigned x)
{
    return x + 2425670281U;
}

unsigned getval_197()
{
    return 3284240739U;
}

void setval_485(unsigned *p)
{
    *p = 2462747032U;
}

unsigned getval_119()
{
    return 3286272328U;
}

void setval_234(unsigned *p)
{
    *p = 2430634344U;
}

void setval_308(unsigned *p)
{
    *p = 3687104905U;
}

unsigned getval_199()
{
    return 3599323059U;
}

void setval_370(unsigned *p)
{
    *p = 3677935305U;
}

void setval_410(unsigned *p)
{
    *p = 3769190577U;
}

void setval_323(unsigned *p)
{
    *p = 3348152713U;
}

void setval_338(unsigned *p)
{
    *p = 3525364361U;
}

void setval_112(unsigned *p)
{
    *p = 3224947401U;
}

unsigned addval_262(unsigned x)
{
    return x + 3683959177U;
}

unsigned addval_447(unsigned x)
{
    return x + 3677932161U;
}

unsigned addval_364(unsigned x)
{
    return x + 3286270280U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
