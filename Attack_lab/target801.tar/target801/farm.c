/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_137(unsigned *p)
{
    *p = 1724078134U;
}

unsigned getval_294()
{
    return 2425393224U;
}

unsigned addval_279(unsigned x)
{
    return x + 3284633944U;
}

void setval_150(unsigned *p)
{
    *p = 3351742792U;
}

unsigned addval_267(unsigned x)
{
    return x + 3347662866U;
}

unsigned getval_181()
{
    return 2428995912U;
}

void setval_118(unsigned *p)
{
    *p = 2425641191U;
}

unsigned addval_464(unsigned x)
{
    return x + 3116587013U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_262(unsigned x)
{
    return x + 3677930125U;
}

unsigned getval_123()
{
    return 3385115273U;
}

void setval_282(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_215()
{
    return 3682914729U;
}

unsigned getval_415()
{
    return 2447411528U;
}

unsigned getval_243()
{
    return 3523268233U;
}

unsigned addval_497(unsigned x)
{
    return x + 3281044097U;
}

unsigned getval_135()
{
    return 3676884617U;
}

unsigned getval_225()
{
    return 3222851209U;
}

unsigned addval_217(unsigned x)
{
    return x + 2430634824U;
}

unsigned getval_322()
{
    return 3281044105U;
}

void setval_472(unsigned *p)
{
    *p = 3380924105U;
}

unsigned getval_277()
{
    return 2425668233U;
}

unsigned getval_430()
{
    return 3286272320U;
}

unsigned getval_443()
{
    return 2497743176U;
}

unsigned addval_418(unsigned x)
{
    return x + 3269495112U;
}

void setval_303(unsigned *p)
{
    *p = 3281047945U;
}

void setval_382(unsigned *p)
{
    *p = 650301833U;
}

unsigned addval_317(unsigned x)
{
    return x + 3286272328U;
}

void setval_130(unsigned *p)
{
    *p = 3348152969U;
}

unsigned getval_195()
{
    return 2463205704U;
}

void setval_458(unsigned *p)
{
    *p = 3224948233U;
}

void setval_263(unsigned *p)
{
    *p = 3767094291U;
}

unsigned addval_173(unsigned x)
{
    return x + 3676361161U;
}

unsigned getval_113()
{
    return 3682913929U;
}

void setval_191(unsigned *p)
{
    *p = 3376988809U;
}

unsigned getval_318()
{
    return 3524841097U;
}

unsigned addval_414(unsigned x)
{
    return x + 3221803433U;
}

unsigned getval_246()
{
    return 3682914697U;
}

void setval_214(unsigned *p)
{
    *p = 3284306298U;
}

unsigned getval_275()
{
    return 2429454712U;
}

void setval_393(unsigned *p)
{
    *p = 3525890441U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
